def classFactory(iface):
    from .main import GeohashGeneratorPlugin
    return GeohashGeneratorPlugin(iface)
